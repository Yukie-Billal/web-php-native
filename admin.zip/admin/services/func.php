<?php

include __DIR__ . "/auth.php";